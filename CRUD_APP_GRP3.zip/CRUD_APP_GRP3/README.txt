The main .exe file is the MAIN_CRUD_APP_EXE file. No dependencies are required, only your MySQL database server and your authentication details for the local MySQL server.

The source code is within the data_files, in the crud_app_main.py
-------------------------------------------------------------------

If you wish to run the python file itself, you can do so by installing the dependencies first in the requirements.txt by typing

pip install -r requirements.txt

in your terminal.